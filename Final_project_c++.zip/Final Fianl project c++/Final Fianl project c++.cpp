#include<iostream>
#include<string>
#include<algorithm>
#include<Windows.h>
using namespace std;



struct Student { // for structure Student
	string name = "";
	int weekly_ex = 0;
	float weekly_grade = 0;
	float final_exam = 0;
	float final_grade = 0;
};
/*
When user insert number 1: the programme will allow to
insert student's information

When user insert number 2: the programme will print out
the student's information

When user insert number 3: the programme will sort the students by grade

When user insert number 4: the programme will sort the students by name

when user insert number 5: exit the programme 
*/

bool compareGrade(Student& a, Student& b){
 return (a.final_grade < b.final_grade);
}


bool compareName(Student& a, Student& b) {
	return (a.name < b.name);
}
int main() {
	Student stu[20]; // array for the student number max 20
	int count = 0; // to count the number of student inserted
	int user_input;
	bool check_out = false;



	cout << "-------Plaese enter one of the Number between 1/2/3/4/5 after the text ->Your input: according to your wish------- ";
	do {



		cout << "\n1:Insert student's info\n2:Print out the student info\n3:Sort by grade (ascending)\n4:Sort by name (ascending)\n5:Exit the program";
		cout << "\n Your input: ";
		cin >> user_input;
		switch (user_input)
		{
		case 1: {
			system("cls");
			cout << "Insert student's name: "; //for student info
			string a;
			cin.ignore(); // to ignore the line and giving space
			getline(cin, a);
			stu[count].name = a;



			cout << "Insert the number of weekly exercises: "; //for weekly exercises
			cin >> stu[count].weekly_ex;



			if (stu[count].weekly_ex <= 19) {
				stu[count].weekly_grade = 0, // for weekly grade checking
					cout << " Weekly exercise grade: " << stu[count].weekly_grade << endl;
			}
			else if (stu[count].weekly_ex >= 20 && stu[count].weekly_ex <= 23) {
				stu[count].weekly_grade = 1,
					cout << " Weekly exercise grade: " << stu[count].weekly_grade << endl;
			}
			else if (stu[count].weekly_ex >= 24 && stu[count].weekly_ex <= 27) {
				stu[count].weekly_grade = 2,
					cout << " Weekly exercise grade: " << stu[count].weekly_grade << endl;
			}
			else if (stu[count].weekly_ex >= 28 && stu[count].weekly_ex <= 32) {
				stu[count].weekly_grade = 3,
					cout << " Weekly exercise grade: " << stu[count].weekly_grade << endl;
			}
			else if (stu[count].weekly_ex >= 33 && stu[count].weekly_ex <= 36) {
				stu[count].weekly_grade = 4,
					cout << " Weekly exercise grade: " << stu[count].weekly_grade << endl;
			}
			else if (stu[count].weekly_ex >= 37 && stu[count].weekly_ex >= 40) {
				stu[count].weekly_grade = 5,
					cout << " Weekly exercise grade: " << stu[count].weekly_grade << endl;
			}
			cout << "Insert the final assignment Grade: "; // for final assignment grade input
			cin >> stu[count].final_exam;
			stu[count].final_grade = double(stu[count].weekly_grade * 0.4 + stu[count].final_exam * 0.6); // for 40% + 60% calculation
			count++;
			break;
		}
		case 2: {
			system("cls");
			for (int i = 0; i < count; i++) { //for student info output
				cout << "Student Number: " << i + 1 << endl;
				cout << "Student Name : " << stu[i].name << endl;
				cout << "Student Weekly Exercises : " << stu[i].weekly_ex << endl;
				cout << "Student Weekly Exercise Grade : " << stu[i].weekly_grade << endl;
				cout << "Student Final Assighnment Grade : " << stu[i].final_exam << endl;
				cout << "Student Final Grade : " << stu[i].final_grade << endl;
			}
			break;
		}
		case 3: {  // to sort by grade
			system("cls");
			sort(stu, stu + count, compareGrade);
			cout << "\n-----Sorted list by grade please press 2 to display the sorted list---------" << endl;
			break;
		}
		case 4: {  // to sort by name
			system("cls");
			sort(stu, stu + count, compareName);
			cout << "\n-----Sorted list by name please press 2 to display the sorted list ----------" << endl;
			break;
		}
		case 5: { // to exit the programme
			system("cls");
			check_out = true;
			cout << " Thank you for using this programme ! Bye bye !!!" << endl;
			break;
		}
		default:
			break;
		}
	} while (!check_out);
	return 0;
}