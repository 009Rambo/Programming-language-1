#pragma once
#include <string>
using namespace std;

struct Student { // for structure Student
	string name = "";
	int weekly_ex = 0;
	float weekly_grade = 0;
	float final_exam = 0;
	float final_grade = 0;
};

bool compareGrade(Student& a, Student& b) {
	return (a.final_grade < b.final_grade);
}

bool compareName(Student& a, Student& b) {
	return (a.name < b.name);
}